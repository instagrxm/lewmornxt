<?php

namespace React\Tests\Dns;

class CallableStub
{
    public function __invoke()
    {
    }
}
