<?php

namespace React\Dns\Query;

class TimeoutException extends \Exception
{
}
