.. _reference.guid.fields:

============
Guid\\Fields
============

.. php:namespace:: Ramsey\Uuid\Guid

.. php:class:: Fields

    Implements :php:interface:`Ramsey\\Uuid\\Rfc4122\\FieldsInterface`.

    Guid\Fields represents the fields of a GUID.
