.. _reference.nonstandard.fields:

===================
Nonstandard\\Fields
===================

.. php:namespace:: Ramsey\Uuid\Nonstandard

.. php:class:: Fields

    Implements :php:interface:`Ramsey\\Uuid\\Rfc4122\\FieldsInterface`.

    Nonstandard\Fields represents the fields of a nonstandard UUID.
