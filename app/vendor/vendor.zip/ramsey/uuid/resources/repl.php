#!/usr/bin/env php
<?php

declare(strict_types=1);

require_once dirname(__FILE__) . '/../vendor/autoload.php';

Psy\bin()();
