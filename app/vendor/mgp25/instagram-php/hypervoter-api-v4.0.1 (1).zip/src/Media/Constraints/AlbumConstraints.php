<?php

namespace InstagramAPI\Media\Constraints;

/**
 * Instagram's timeline album media constraints.
 */
class AlbumConstraints extends TimelineConstraints
{
}
